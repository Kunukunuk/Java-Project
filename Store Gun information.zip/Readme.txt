The format of the input file are the parameters separated by a ',' minues the primary key
because I set the primary key to auto increment.
The format of the output file are the parameter names, insert data at time, show the whole table after insertion,
delete data at times, show the whole table after deletion, modify the data, show the whole table after modification,
search for query and then show the query result's name.
My program creates the table in a database, insert, modify, delete, do query and then deletese the table at the end of the program.